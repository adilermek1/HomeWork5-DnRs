function T3 = T3_RRR(q,s,L)
T3 = Rz(q(1))*Tx(s)*Tx(2*L);
end