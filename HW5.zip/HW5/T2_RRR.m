function T2 = T2_RRR(q,s)
T2 = Rz(q(1))*Tx(s);
end